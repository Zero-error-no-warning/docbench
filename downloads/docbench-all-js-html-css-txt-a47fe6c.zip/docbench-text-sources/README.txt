DocBench ソースのテキスト書き出し

対象コミット: a47fe6c074d612326c0a4e53babe10b02834d9aa

リポジトリ内の全 .js / .html / .css ファイル 43 個を含みます。
開発用依存ライブラリ node_modules、テスト結果、Git管理情報は含みません。
vendor に同梱された実行時ライブラリと、そのライセンス 11 個を含みます。

元のフォルダー構成とファイル内容を保ち、ファイル名の末尾に .txt を追加しています。
例: src/app.js → src/app.js.txt / index.html → index.html.txt
元の拡張子を残すことで、同名の .js と .css の衝突を防いでいます。

このZIPは閲覧・共有用です。復元する場合は、各ソースファイル名の末尾の .txt を外してください。
元ファイルとの対応・内容のSHA256は MANIFEST.txt に記載しています。
